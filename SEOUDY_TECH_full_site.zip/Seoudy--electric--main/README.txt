SEOUDY TECH - Arabic Dark Site (Admin + Public)
-----------------------------------------------
- الموقع عربي بالكامل بتصميم داكن وألوان زاهية.
- استبدال كامل لخدمات الكهرباء بخدمات الإلكترونيات (جوال/كمبيوتر/برامج).
- تم إدراج الصور التي زودتني بها كلوجو وصور خدمات.
- لوحة مشرف في /admin/ متصلة بـ Firebase (Auth + Firestore + Storage).

خطوات سريعة:
1) فعّل Firebase: Authentication (Email/Password) + Firestore + Storage.
2) أنشئ مستخدم المشرف: elmshrky666666@gmail.com / asm1980ASM.
3) ارفع المجلد هذا على Vercel (Upload Folder) أو عبر GitHub ثم Import إلى Vercel.
4) رابط لوحة المشرف: https://<your-site>/admin/

أمان:
- عدل قواعد Firestore/Storage للسماح بالكتابة فقط للمستخدمين المسجلين.
