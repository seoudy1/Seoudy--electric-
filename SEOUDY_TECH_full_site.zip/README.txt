ارفع المجلد على Vercel كموقع ثابت. لوحة المشرف: /admin/ — كلمة المرور: asm1980ASM@
Supabase bucket: images
